"""This package provides the xAI integration for LangChain."""

from langchain_xai.chat_models import ChatXAI

__all__ = ["ChatXAI"]
